package com.example.notif_3102

import android.app.*
import android.content.*
import android.os.*
import androidx.core.app.NotificationCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {

        // 1. Ambil Pesan dari Intent
        val message = intent.getStringExtra("PESAN") ?: "Waktunya aktivitas!"

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "alarm_channel_3102"

        // 2. Buat Channel (Android O+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Alarm Notif",
                NotificationManager.IMPORTANCE_HIGH
            )
            notificationManager.createNotificationChannel(channel)
        }

        // 3. Tampilkan Notifikasi dengan Pesan Kustom
        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("PENGINGAT") // Judul
            .setContentText(message)      // Isi pesan dari EditText
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        notificationManager.notify(123, builder.build())
    }
}